//
//  Squeak_MIDI.h - glue code for the Squeak MIDI primitives that use PortMIDI
//
//  Created by Stephen Travis Pope on 12/7/22.
//

#ifndef SQ_MIDI_h
#define SQ_MIDI_h

#include "portmidi.h"
#include <stdio.h>            // UNIX includes
#include <string.h>            // for memcpy, bzero, etc.
#include "stdlib.h"            // UNIX includes
#include "stdio.h"
#include "string.h"
#include "assert.h"

// for testing

int32_t sqMIDITest(void) { return (uint32_t) 42; }

// Initialize the PM world

int32_t sqMIDIInitialize(void);

// Close up shop

int32_t sqMIDITerminate(void);

// Answer the port count

int32_t sqMIDIGetPortCount(void);

// Answer the default out device

int32_t sqMIDIGetDefaultOutDevice(void);

// Answer the default in device

int32_t sqMIDIGetDefaultInDevice(void);

// Open an input port

int32_t sqMIDIOpenInPort(int32_t device);

// Open an output port

int32_t sqMIDIOpenOutPort(int32_t device);

// Read events into a buffer

int32_t sqMIDIPortReadInto(int32_t portNum, int32_t count, char * bufferPtr);

// Write a short event message

int32_t sqMIDIWriteShort(int32_t portNum, uint32_t data);

// Write events from a buffer

int32_t sqMIDIPortWriteFromAt(int32_t portNum, int32_t count, char * bufferPtr, int32_t time);


// ToDo ////////////////////////////////////////////////

//uint32_t sqMIDIGetClock(void);
//uint32_t sqMIDIGetPortDirectionality(int portNum);

//uint32_t sqMIDIGetPortName(int portNum, char *namePtr, int length);
//uint32_t sqMIDIClosePort(int portNum);

//uint32_t sqMIDIParameterSet(int whichParameter, int newValue);
//uint32_t sqMIDIParameterGet(int whichParameter);

#endif /* SQ_MIDI_h */
