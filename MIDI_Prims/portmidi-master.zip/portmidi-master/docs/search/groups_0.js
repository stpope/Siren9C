var searchData=
[
  ['basic_20definitions_0',['Basic Definitions',['../group__grp__basics.html',1,'']]]
];
