README.txt
Roger B. Dannenberg
2 Jan 2009

PmDefaults is a program to set default input and output devices for
PortMidi applications. After running the PmDefaults program and
choosing devices, identifiers for these devices will be returned by
calls (within any program) to Pm_GetDefaultInputDeviceID() and
Pm_GetDefaultOutputDeviceID().

Included in this directory are:

manifest.txt -- used in pmdefaults.jar
pmdefaults-license.txt -- license text
pmdefaults-icon.{bmp,xcf,png,gif} -- icons
pmdefaults.{ico,icns} - icons
portmusic_logo.png -- a logo displayed by the pmdefaults application

TO BUILD AND RUN THE APPLICATION: see ../README.txt

