var searchData=
[
  ['structversion_0',['structVersion',['../struct_pm_device_info.html#a427b2098449590745eb8e4443f0b4ef8',1,'PmDeviceInfo']]]
];
