var struct_pm_device_info =
[
    [ "input", "struct_pm_device_info.html#adfab4eebf850cff6c1c1c4b8aa408293", null ],
    [ "interf", "struct_pm_device_info.html#a4de98640fcb0246b461a25d12987fb7e", null ],
    [ "is_virtual", "struct_pm_device_info.html#aa739c3e575ae24a9b4dafc487149e7d1", null ],
    [ "name", "struct_pm_device_info.html#a5ac083a645d964373f022d03df4849c8", null ],
    [ "opened", "struct_pm_device_info.html#af2606797deda70b5effbc50b2648d699", null ],
    [ "output", "struct_pm_device_info.html#a76a055a540e12c7206a5004afea1f66e", null ],
    [ "structVersion", "struct_pm_device_info.html#a427b2098449590745eb8e4443f0b4ef8", null ]
];