var annotated_dup =
[
    [ "PmDeviceInfo", "struct_pm_device_info.html", "struct_pm_device_info" ],
    [ "PmEvent", "struct_pm_event.html", null ],
    [ "PmQueueRep", "struct_pm_queue_rep.html", null ]
];