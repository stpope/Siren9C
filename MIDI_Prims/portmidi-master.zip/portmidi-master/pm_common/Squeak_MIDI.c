//
//  Squeak_MIDI.c - glue code for the Squeak MIDI primitives that use PortMIDI
//  
//  Created by Stephen Travis Pope on 12/7/22.
//

#include "Squeak_MIDI.h"
#include "portmidi.h"

int pm_inited = 0;
PortMidiStream * pm_in_stream = 0;
PortMidiStream * pm_out_stream = 0;
#define BUF_LEN 256
char midi_buffer[BUF_LEN] = {0};
PmEvent evt_buffer[BUF_LEN] = {0};
#define NULL 0

// check that we're initialized

#define CHECK_PM_INIT               \
    int32_t err = 0;               \
    if (! pm_inited) {              \
        err = Pm_Initialize();      \
        pm_inited = 1;              \
    }

// Initialize the PM world

int32_t sqMIDIInitialize() {
    CHECK_PM_INIT
    return err;
}

// Close up shop

int32_t sqMIDITerminate() {
    int err = Pm_Terminate();
    pm_inited = 0;
    pm_in_stream = 0;
    pm_out_stream = 0;
    return err;
}

// Answer the port count

int32_t sqMIDIGetPortCount(void) {
    CHECK_PM_INIT
    return (int32_t) Pm_CountDevices();
}

// Answer the default out device

int32_t sqMIDIGetDefaultOutDevice(void) {
    CHECK_PM_INIT
    return (int32_t) Pm_GetDefaultOutputDeviceID();
}

// Answer the default in device

int32_t sqMIDIGetDefaultInDevice(void) {
    CHECK_PM_INIT
    return (int32_t) Pm_GetDefaultInputDeviceID();
}

// Open an input port

//    PMEXPORT PmError Pm_OpenInput(PortMidiStream** stream,
//                    PmDeviceID inputDevice,
//                    void *inputDriverInfo,
//                    int32_t bufferSize,
//                    PmTimeProcPtr time_proc,
//                    void *time_info);

int32_t sqMIDIOpenInPort(int32_t device) {
    CHECK_PM_INIT
    return (int32_t) Pm_OpenOutput(& pm_in_stream, device, NULL, 4, NULL, NULL, 0);
}

// Open an output port

//    PMEXPORT PmError Pm_OpenOutput(PortMidiStream** stream,
//                    PmDeviceID outputDevice,
//                    void *outputDriverInfo,
//                    int32_t bufferSize,
//                    PmTimeProcPtr time_proc,
//                    void *time_info,
//                    int32_t latency);

int32_t sqMIDIOpenOutPort(int32_t device) {
    CHECK_PM_INIT
    return (int32_t) Pm_OpenOutput(& pm_out_stream, device, NULL, 4, NULL, NULL, 0);
}

// Read events into a buffer

// PMEXPORT int Pm_Read(PortMidiStream *stream, PmEvent *buffer, int32_t length);

//            typedef uint32_t PmMessage; /**< @brief see #PmEvent */
//            typedef struct {
//                PmMessage      message;
//                PmTimestamp    timestamp;
//            } PmEvent;

int32_t sqMIDIPortReadInto(int32_t portNum, int32_t count, char * bufferPtr) {
    CHECK_PM_INIT
    return (int32_t) Pm_Read(pm_in_stream, evt_buffer, BUF_LEN);
}

// Write a short event message

//    PMEXPORT PmError Pm_WriteShort(PortMidiStream *stream, PmTimestamp when,
//                                   PmMessage msg);

int32_t sqMIDIWriteShort(int32_t portNum, uint32_t data) {
    CHECK_PM_INIT
    return (int32_t) Pm_WriteShort(pm_out_stream, 0, data);
}

// Write events from a buffer

//    PMEXPORT PmError Pm_Write(PortMidiStream *stream, PmEvent *buffer,
//                              int32_t length);

int32_t sqMIDIWriteBuffer(int32_t portNum, int count, char * bufferPtr) {
    CHECK_PM_INIT
    return (int32_t) Pm_Write(pm_out_stream, evt_buffer, count);
}

