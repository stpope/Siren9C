var group__grp__device =
[
    [ "Pm_CreateVirtualInput", "group__grp__device.html#gaf262cf560e105c9a44f7b30eb868951e", null ],
    [ "Pm_CreateVirtualOutput", "group__grp__device.html#gad72a83e522ff11431c2ab1fc87508e9e", null ],
    [ "Pm_DeleteVirtualDevice", "group__grp__device.html#gaea134247f51e10b217abd31a352ee633", null ],
    [ "Pm_GetDeviceInfo", "group__grp__device.html#gab5974cf4a7995002e83bd9410a16470d", null ],
    [ "Pm_OpenInput", "group__grp__device.html#gabd50a31baaa494ad8b405f9ad54c966e", null ],
    [ "Pm_OpenOutput", "group__grp__device.html#ga134924cfa8badeecff3c5e1f22aee178", null ]
];