/* pmwinmm.h -- system-specific definitions for windows multimedia API */

void pm_winmm_init( void );
void pm_winmm_term( void );

