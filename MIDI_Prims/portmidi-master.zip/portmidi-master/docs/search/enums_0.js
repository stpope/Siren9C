var searchData=
[
  ['pmerror_0',['PmError',['../group__grp__basics.html#ga5fd46ccd2e320e17a840886731e8c6b9',1,'portmidi.h']]],
  ['pterror_1',['PtError',['../group__grp__porttime.html#gacfaa38b7bc53259ca92514f2b2c02484',1,'porttime.h']]]
];
