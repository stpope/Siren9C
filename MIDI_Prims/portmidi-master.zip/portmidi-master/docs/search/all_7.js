var searchData=
[
  ['reading_20and_20writing_20midi_20messages_0',['Reading and Writing Midi Messages',['../group__grp__io.html',1,'']]]
];
