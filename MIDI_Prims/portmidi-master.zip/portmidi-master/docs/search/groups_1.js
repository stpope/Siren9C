var searchData=
[
  ['events_20and_20filters_20handling_0',['Events and Filters Handling',['../group__grp__events__filters.html',1,'']]]
];
