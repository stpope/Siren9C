var searchData=
[
  ['name_0',['name',['../struct_pm_device_info.html#a5ac083a645d964373f022d03df4849c8',1,'PmDeviceInfo']]]
];
