var modules =
[
    [ "Lock-free Queue", "group__grp__pmutil.html", "group__grp__pmutil" ],
    [ "Basic Definitions", "group__grp__basics.html", "group__grp__basics" ],
    [ "Input/Output Devices Handling", "group__grp__device.html", "group__grp__device" ],
    [ "Events and Filters Handling", "group__grp__events__filters.html", "group__grp__events__filters" ],
    [ "Reading and Writing Midi Messages", "group__grp__io.html", "group__grp__io" ],
    [ "PortTime: Millisecond Timer", "group__grp__porttime.html", "group__grp__porttime" ]
];