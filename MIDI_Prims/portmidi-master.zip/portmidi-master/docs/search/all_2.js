var searchData=
[
  ['input_0',['input',['../struct_pm_device_info.html#adfab4eebf850cff6c1c1c4b8aa408293',1,'PmDeviceInfo']]],
  ['input_2foutput_20devices_20handling_1',['Input/Output Devices Handling',['../group__grp__device.html',1,'']]],
  ['interf_2',['interf',['../struct_pm_device_info.html#a4de98640fcb0246b461a25d12987fb7e',1,'PmDeviceInfo']]],
  ['is_5fvirtual_3',['is_virtual',['../struct_pm_device_info.html#aa739c3e575ae24a9b4dafc487149e7d1',1,'PmDeviceInfo']]]
];
